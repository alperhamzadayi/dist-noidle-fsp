

void GRASP(vector <int> &pmSpan, vector<vector<vector<unsigned short> > > &pSeq,vector <double> &pETime, int pLen, double alfa_parameter)
{
	vector<vector<unsigned short>> TempSeq,bestSeqSoFar,Seq;
	int mSpan, bestSpanSoFar,TSpan;
	mSpan=In�t_Seq(Seq, alfa_parameter); 
	bestSpanSoFar=mSpan;
	bestSeqSoFar=Seq;
	TempSeq=Seq; 
	int counter = 0;
	
	pmSpan.clear();
	pSeq.clear();
	pETime.clear();
	int OutPoint=1;
	while(true)
	{		
		TSpan=Destruction_Construction_it(TempSeq,pLen, alfa_parameter); //operator.h

		if(TSpan<=mSpan)
		{
			mSpan=TSpan;
			Seq=TempSeq;
			if(mSpan<bestSpanSoFar)
			{
				bestSpanSoFar=mSpan;
				bestSeqSoFar=Seq;
			}
		}
		
		long ElapseTime=::GetTickCount()-InitTime;
		if(ElapseTime >=TimeLimit*OutPoint/3)
		{
			pmSpan.push_back(bestSpanSoFar);
			pSeq.push_back(bestSeqSoFar);			
			pETime.push_back(ElapseTime);
			OutPoint++;
			if(OutPoint>3) break;			
		}
	}
}


