#include "stdafx.h"
#include "com.h"
#include "Operator.h"
#include "Ins.h"
#include "GRASP.h"
#include "MetaHeu.h"



int main()
{
	int DataType = 1; //1 for small instances //2 for large instances
	int Replication = 5;
	srand(time(NULL));
	printf("\n 1_small instances; 2_large_instances =:%d", DataType);
	printf("\n Number of Replication=:%d", Replication);
	MetaHeu(DataType, Replication);
	//PARAMETERS DEFINED IN MetaHeu.h 
		  
    printf("\n All of the instances are solved");	
	getchar();
}



