//com.h
#include <windows.h>         
#include "stdlib.h"
#include "time.h"
#include "stdio.h"
#include "math.h"
#include <conio.h>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

//for instances
int gJobs, gMachines, gFactory;
vector <short> pTime;
vector <vector <int> > CTime, STime, CTimeb, STimeb;
vector <vector <int> > Fcmax; 
vector <int> TSTime, TCTime, TCTimeb, TSTimeb;
long InitTime;
long TimeLimit;
int Max_Pos;
FILE *Sonuc;


// -------------for sorting----------
typedef struct
{
	int dim;
	int value;
} Pair;

class PairGreater {
public:
	bool operator () (Pair a, Pair b)
	{
		return a.value>b.value;
	}
};

class PairLess {
public:
	bool operator () (Pair a, Pair b)
	{
		return a.value<b.value;
	}
};

void SPT(vector <unsigned short> &chrom)
{
	Pair *ch = new Pair[gJobs];
	for (int i = 0; i<gJobs; i++)
	{
		ch[i].dim = i;
		ch[i].value = 0;
		for (int j = 0; j<gMachines; j++)
		{
			ch[i].value += pTime[i*gMachines + j];
		}
	}
	sort(ch, ch + gJobs, PairLess());
	for (int i = 0; i<gJobs; i++)
	{
		chrom[i] = ch[i].dim;
	}
	delete[]ch;
}

void LPT(vector <unsigned short> &chrom)
{
	Pair *ch = new Pair[gJobs];
	for (int i = 0; i<gJobs; i++)
	{
		ch[i].dim = i;
		ch[i].value = 0;
		for (int j = 0; j<gMachines; j++)
		{
			ch[i].value += pTime[i*gMachines + j];
		}
	}
	sort(ch, ch + gJobs, PairGreater());
	for (int i = 0; i<gJobs; i++)
	{
		chrom[i] = ch[i].dim;
	}
	delete[]ch;
}

void initTempArray()
{
	CTime.clear();
	CTime.resize(gMachines);
	for (int i = 0; i<gMachines; i++)
		CTime[i].resize(gJobs);
	STime = CTime;
	CTimeb = CTime;
	STimeb = CTime;

	TCTime.clear();
	TCTime.resize(gMachines);
	TSTime = TCTime;
	TCTimeb = TCTime;
	TSTimeb = TCTime;
}

//CTime, Completion time; STime: Starting time
int GetFit_F(vector <unsigned short> chrom, int Len)//forward pass calculation
{
	int i, l, Cmax;
	//First n
	STime[0][0] = 0;
	CTime[0][0] = STime[0][0] + pTime[chrom[0] * gMachines];
	for (i = 1; i < gMachines; i++)
	{
		STime[i][0] = CTime[i - 1][0];
		CTime[i][0] = STime[i][0] + pTime[chrom[0] * gMachines + i];
	}

	//Other jobs
	for (l = 1; l < Len; l++)
	{
		// First Machine
		STime[0][l] = CTime[0][l - 1];
		CTime[0][l] = STime[0][l] + pTime[chrom[l] * gMachines];

		// Second Machine
		STime[1][l] = max(CTime[1][l - 1], CTime[0][l]);
		CTime[1][l] = STime[1][l] + pTime[chrom[l] * gMachines + 1];

		int a = 0;
		a = max(CTime[0][l] - CTime[1][l - 1], 0);

		// Rest machines;
		for (i = 2; i < gMachines; i++)
		{
			STime[i][l] = max(CTime[i][l - 1] + a, CTime[i - 1][l]);
			CTime[i][l] = STime[i][l] + pTime[chrom[l] * gMachines + i];
			a += max(CTime[i - 1][l] - (CTime[i][l - 1] + a), 0);
		}
	}

	Cmax = CTime[gMachines - 1][Len - 1];

	return Cmax;
}

// STimeb: reverse starting time; CTimeb: reverse completion time;
int GetFit_B(vector <unsigned short> chrom, int Len) //Backward pass calculation
{
	int i = gMachines - 1;
	int l = Len - 1, Cmax;

	//last n
	STimeb[i][l] = 0;
	CTimeb[i][l] = STimeb[i][l] + pTime[chrom[l] * gMachines + i];

	for (i = gMachines - 2; i >= 0; i--)
	{
		STimeb[i][l] = CTimeb[i + 1][l];
		CTimeb[i][l] = STimeb[i][l] + pTime[chrom[l] * gMachines + i];
	}

	// from second last n to the first one;
	for (l = Len - 2; l >= 0; l--)
	{
		// the last operation
		STimeb[gMachines - 1][l] = CTimeb[gMachines - 1][l + 1];
		CTimeb[gMachines - 1][l] = STimeb[gMachines - 1][l] + pTime[chrom[l] * gMachines + gMachines - 1];

		// second last operation
		STimeb[gMachines - 2][l] = max(CTimeb[gMachines - 2][l + 1], CTimeb[gMachines - 1][l]);
		CTimeb[gMachines - 2][l] = STimeb[gMachines - 2][l] + pTime[chrom[l] * gMachines + gMachines - 2];

		int a = 0;
		a = max(CTimeb[gMachines - 1][l] - CTimeb[gMachines - 2][l + 1], 0);

		// the rest machines;
		for (i = gMachines - 3; i >= 0; i--)
		{
			STimeb[i][l] = max(CTimeb[i][l + 1] + a, CTimeb[i + 1][l]);
			CTimeb[i][l] = STimeb[i][l] + pTime[chrom[l] * gMachines + i];
			a += max(CTimeb[i + 1][l] - (CTimeb[i][l + 1] + a), 0);
		}
	}

	Cmax = CTimeb[0][0];
	return Cmax;
}

int GetFit(vector<unsigned short> chrom, int Len )
{
	int Cmax = GetFit_F(chrom, Len);
	//	int Temp=GetFit_B(chrom,Len);
	//	if(Cmax!=Temp) printf("==");
	return Cmax;
}

void CheckChrom(vector<vector<unsigned short>> p , int makespan)
{

	bool bError = false;
	vector <bool> bExist(gJobs, false);

	for (int i = 0; i < gFactory; i++) {

		for (int j = 0; j < p[i].size(); j++) {
            bExist[p[i][j]] = true;
		}
	}

	for (int i = 0; i<gJobs; i++)
	{
		if (!bExist[i])
		{
			bError = true;
			printf("**");
		}
	}

	int factory_makespan;
	int calculated_makespan = 0;
	for (int i = 0; i < gFactory; i++) {
		factory_makespan = GetFit(p[i], p[i].size());
		if (factory_makespan > calculated_makespan) {
			calculated_makespan = factory_makespan;
		}
	}
	//maksespan check
	if (makespan != calculated_makespan) bError = true;

	if (bError)
	{
		printf("\nError\n!");
		FILE *f1;
		f1 = fopen("error.txt", "a+");
		fprintf(f1, "\n");
		fprintf(f1, "%4d,%4d,%8d", gJobs, gMachines, makespan);
		fclose(f1);
	}
}
