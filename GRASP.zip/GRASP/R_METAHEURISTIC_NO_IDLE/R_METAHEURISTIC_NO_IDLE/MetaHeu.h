void MetaHeu(short DataType, short Rep)
{

	if (DataType == 1) { //Small instances

		FILE *f, *f1, *f2;
		char FName[100] = "RESULTS\\GRASP\\SMALL\\Span_", TName[100] = "RESULTS\\GRASP\\SMALL\\Time_", SeqName[100] = "RESULTS\\GRASP\\SMALL\\Seq_", Buf[100] = "", TempBuf[100];

		_itoa(DataType, TempBuf, 10);
		strcat(Buf, TempBuf);
		strcat(FName, Buf);
		strcat(FName, ".m");
		strcat(TName, Buf);
		strcat(TName, ".m");
		strcat(SeqName, Buf);
		strcat(SeqName, ".txt");

		f = fopen(FName, "w");
		f1 = fopen(TName, "w");

		char TFArray[100] = "Span", TimeArray[100] = "Time";
		strcat(TFArray, Buf);
		strcat(TFArray, "=[");
		strcat(TimeArray, Buf);
		strcat(TimeArray, "=[");
		fprintf(f, "%s", TFArray);
		fprintf(f1, "%s", TimeArray);
		fclose(f);
		fclose(f1);

		f2 = fopen(SeqName, "w");
		fclose(f2);

		for (int Ins = 1 ; Ins <= 420; Ins++) //TOTAL SMALL INSTANCES
		{
			GetBenchmark(Ins, 1, 0); //Ins.h //1_small instances; 2_large instances
			initTempArray(); //com.hF
			int BestSpan = INT_MAX;
			vector<vector<unsigned short>> BestSeq;
			f = fopen(FName, "a");
			f1 = fopen(TName, "a");
			fprintf(f, "\n");
			fprintf(f1, "\n");

			for (int r = 1; r <= Rep; r++)
			{
				
				//PARAMETERS
				int pLen = 2; 
				TimeLimit = gMachines *gJobs * 90;
				double 	alfa_parameter = 0.5;
				//srand(100+r);			
				vector <unsigned short> Seq(gJobs);
				InitTime = ::GetTickCount();
				vector <int> pmSpan;
				vector<vector<vector<unsigned short> > > pSeq;
				vector <double> pETime;

				GRASP(pmSpan, pSeq, pETime, pLen, alfa_parameter);
					
				vector<vector<unsigned short>> CheckSeq;
				for (int xx = 0; xx < pSeq.size(); xx++) {
					CheckSeq = pSeq[xx];
					CheckChrom(CheckSeq, pmSpan[xx]);//com.h	
				}

				if (pmSpan[2] < BestSpan)
				{
					BestSpan = pmSpan[2];
					BestSeq = pSeq[2];
				}
				printf("\n%3d,%1d,%7d,%7d,%7d,%7.2f,%7.2f,%7.2f", Ins, r, pmSpan[0], pmSpan[1], pmSpan[2], pETime[0], pETime[1], pETime[2]);
				fprintf(f, "%7d,%7d,%7d,", pmSpan[0], pmSpan[1], pmSpan[2]);
				fprintf(f1, "%7.2lf,%7.2lf,%7.2lf,", pETime[0], pETime[1], pETime[2]);
				printf("\n");
			}

			fclose(f);
			fclose(f1);

			f2 = fopen(SeqName, "a");
			fprintf(f2, "\nIns_%-3d\t%8d\t", Ins, BestSpan);
			for (int fac = 0; fac < gFactory; fac++) {
				for (int i = 0; i < BestSeq[fac].size(); i++)
				{
					fprintf(f2, "%4d", BestSeq[fac][i]);
				}
				fprintf(f2, "\t");
			}
			fclose(f2);
		}

		f = fopen(FName, "a");
		f1 = fopen(TName, "a");
		fprintf(f, "];\n");
		fprintf(f1, "];\n");
		fclose(f);
		fclose(f1);
	}

	/******************************************************************************************************/

	else { //Large instances

		for (int mixType = 2; mixType <= 7; mixType++) {

			FILE *f, *f1, *f2;
			char FName[100] = "RESULTS\\GRASP\\LARGE\\Span_", TName[100] = "RESULTS\\GRASP\\LARGE\\Time_", SeqName[100] = "RESULTS\\GRASP\\LARGE\\Seq_", Buf[100] = "", TempBuf[100];

			_itoa(mixType, TempBuf, 10);
			strcat(Buf, TempBuf);
			strcat(FName, Buf);
			strcat(FName, ".m");
			strcat(TName, Buf);
			strcat(TName, ".m");
			strcat(SeqName, Buf);
			strcat(SeqName, ".txt");

			f = fopen(FName, "w");
			f1 = fopen(TName, "w");

			char TFArray[100] = "Span", TimeArray[100] = "Time";
			strcat(TFArray, Buf);
			strcat(TFArray, "=[");
			strcat(TimeArray, Buf);
			strcat(TimeArray, "=[");
			fprintf(f, "%s", TFArray);
			fprintf(f1, "%s", TimeArray);
			fclose(f);
			fclose(f1);

			f2 = fopen(SeqName, "w");
			fclose(f2);

			for (int Ins = 1; Ins <= 120; Ins++)
			{
				GetBenchmark(Ins, 2, mixType); //Ins.h //1_small instances; 2_large instances

				initTempArray(); //com.h
				int BestSpan = INT_MAX;
				vector<vector<unsigned short>> BestSeq;
				f = fopen(FName, "a");
				f1 = fopen(TName, "a");
				fprintf(f, "\n");
				fprintf(f1, "\n");

				for (int r = 1; r <= Rep; r++)
				{
					
					//PARAMETERS
					int pLen = 8; 
					TimeLimit = gMachines *gJobs * 90;
					double 	alfa_parameter = 0.5;
					//srand(100+r);			
					vector <unsigned short> Seq(gJobs);
					InitTime = ::GetTickCount();
					vector <int> pmSpan;
					vector<vector<vector<unsigned short> > > pSeq;
					vector <double> pETime;


				    GRASP(pmSpan, pSeq, pETime, pLen, alfa_parameter);

					vector<vector<unsigned short>> CheckSeq;

					for (int xx = 0; xx < pSeq.size(); xx++) {
						CheckSeq = pSeq[xx];
						CheckChrom(CheckSeq, pmSpan[xx]);//com.h	
					}

					if (pmSpan[2] < BestSpan)
					{
						BestSpan = pmSpan[2];
						BestSeq = pSeq[2];
					}
					printf("\n%2d,%3d,%1d,%7d,%7d,%7d,%7.2f,%7.2f,%7.2f", mixType, Ins, r, pmSpan[0], pmSpan[1], pmSpan[2], pETime[0], pETime[1], pETime[2]);
					fprintf(f, "%7d,%7d,%7d,", pmSpan[0], pmSpan[1], pmSpan[2]);
					fprintf(f1, "%7.2f,%7.2f,%7.2f,", pETime[0], pETime[1], pETime[2]);
					printf("\n");
				}

				fclose(f);
				fclose(f1);

				f2 = fopen(SeqName, "a");
				fprintf(f2, "\nIns_%-3d\t%8d\t", Ins, BestSpan);

				for (int fac = 0; fac < gFactory; fac++) {
					for (int i = 0; i < BestSeq[fac].size(); i++)
					{
						fprintf(f2, "%4d", BestSeq[fac][i]);
					}
					fprintf(f2, "\t");
				}
				fclose(f2);
			}

			f = fopen(FName, "a");
			f1 = fopen(TName, "a");
			fprintf(f, "];\n");
			fprintf(f1, "];\n");
			fclose(f);
			fclose(f1);
		}
	}

}
