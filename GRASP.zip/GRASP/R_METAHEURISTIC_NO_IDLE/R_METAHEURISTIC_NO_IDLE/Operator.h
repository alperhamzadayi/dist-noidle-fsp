//Operator.h
#include <iostream>
#include <random>
using namespace std;

void Insert(vector <unsigned short> &p)
{
	//find two distinct elements randly;
	unsigned short  pt1,pt2,Ward;
	do
	{
		pt1=rand()%p.size();
		pt2=rand()%p.size();
	}while(pt1==pt2);

	if(pt2<pt1)
	{
		unsigned short  temp=pt2;
		pt2=pt1;
		pt1=temp;
	}
	
	Ward=rand()%2;
	//insert foreword;
	if(Ward)
	{
		unsigned short  temp=p[pt2];
		do
		{
			p[pt2]=p[pt2-1];
			pt2=pt2-1;
		}while(pt2>pt1);
		p[pt2]=temp;
	}
	else
	{
		// insert backword;
		unsigned short  temp=p[pt1];
		do
		{
			p[pt1]=p[pt1+1];
			pt1=pt1+1;
		}while(pt1<pt2);
		p[pt1]=temp;
	}
}

int FindBestJobPos(vector <unsigned short> &Chrom, int Len, int Pos)
{
	
	unsigned short Tempch=Chrom[Pos];
	int h=Len-1;
	for(int i=Pos;i<h;i++)
		Chrom[i]=Chrom[i+1];

	GetFit_F(Chrom,h);
	GetFit_B(Chrom,h);
		
	//Find best position from 0,1,...,h-1
	int minSpan=INT_MAX, pt=-1;		
	for(int l=0;l<=h;l++)
	{
		int TempSpan;		
		if(l==0) //backward pass calculation
		{
			// the last operation
			TSTimeb[gMachines-1]= CTimeb[gMachines-1][l];
			TCTimeb[gMachines-1]= TSTimeb[gMachines-1]+pTime[Tempch*gMachines+gMachines-1];
			
			// second last operation
			TSTimeb[gMachines-2]=max(CTimeb[gMachines-2][l],TCTimeb[gMachines-1]);
			TCTimeb[gMachines-2]=TSTimeb[gMachines-2]+pTime[Tempch*gMachines+gMachines-2];
			
			int a=0;
			a=max(TCTimeb[gMachines-1]-CTimeb[gMachines-2][l],0);
				
			
			// the rest machines;
			for(int i=gMachines-3;i>=0;i--)
			{
				TSTimeb[i]=max(CTimeb[i][l]+a,TCTimeb[i+1]);
				TCTimeb[i]=TSTimeb[i]+pTime[Tempch*gMachines+i];
				a+=max(TCTimeb[i+1]-(CTimeb[i][l]+a),0);
			}			
			TempSpan=TCTimeb[0];			
		}
		else if(l<h)
		{
			//Forward calculation for Tempch; ---First Machine
			TSTime[0]=CTime[0][l-1];
			TCTime[0]=TSTime[0]+pTime[Tempch*gMachines];
			// Second Machine
			TSTime[1]=max(CTime[1][l-1],TCTime[0]);
			TCTime[1]=TSTime[1]+pTime[Tempch*gMachines+1];
			int a=0;
			a=max(TCTime[0]-CTime[1][l-1],0);
				
			
			// Rest machines;
			for(int i=2;i<gMachines;i++)
			{
				TSTime[i]=max(CTime[i][l-1]+a,TCTime[i-1]);
				TCTime[i]=TSTime[i]+pTime[Tempch*gMachines+i];
				a+=max(TCTime[i-1]-(CTime[i][l-1]+a),0);
			}
			
			//Get Makespan
			int L=0;
			a=0;
			TempSpan=TCTime[0]+CTimeb[0][l];
			
			L=TCTime[1]+CTimeb[1][l];
			a=max(TempSpan-L,0);
			
			TempSpan=max(TempSpan,L);
			
			for(int i=2;i<gMachines;i++)
			{
				L=TCTime[i]+a+CTimeb[i][l];
				a+=max(TempSpan-L,0);
				TempSpan=max(TempSpan,L);
			}
		}
		else 
		{
			// First Machine
			TSTime[0]=CTime[0][l-1];
			TCTime[0]=TSTime[0]+pTime[Tempch*gMachines];
			
			// Second Machine
			TSTime[1]=max(CTime[1][l-1],TCTime[0]);
			TCTime[1]=TSTime[1]+pTime[Tempch*gMachines+1];
			
			int a=0;
			a=max(TCTime[0]-CTime[1][l-1],0);
			
			// Rest machines;
			for(int i=2;i<gMachines;i++)
			{
				TSTime[i]=max(CTime[i][l-1]+a,TCTime[i-1]);
				TCTime[i]=TSTime[i]+pTime[Tempch*gMachines+i];
				a+=max(TCTime[i-1]-(CTime[i][l-1]+a),0);
			}
			
			TempSpan=TCTime[gMachines-1];							
		}
		
		if(TempSpan<minSpan)
		{
			pt=l;
			minSpan=TempSpan;
		}
		else if(TempSpan==minSpan && rand()%2)
		{
			pt=l;
		}
	}
		
	// insert ch in position pt
	for(int l=h;l>pt;l--) Chrom[l]=Chrom[l-1];
	Chrom[pt]=Tempch;
	return minSpan;
}

int Construction(vector <unsigned short> Sequnece, vector<vector<unsigned short> >  &Newchrom, double alfa_parameter) {
	Newchrom.resize(gFactory);
	vector <unsigned short> job_list(1), new_Seq, Seq;
	Seq = Sequnece;
	int minSpan, Seqsize = Seq.size();

	for (int jnumber = 0; jnumber < Seqsize; jnumber++) { 
		Fcmax.clear();
		Fcmax.resize(Seq.size());
		for (int i = 0; i<Seq.size(); i++)
			Fcmax[i].resize(gFactory);
		/*********************************/
		for (int fac = 0; fac < gFactory; fac++) { 
			bool state = Newchrom[fac].empty(); 
			if (state == true) { 
				job_list.clear();
				job_list.resize(1);
			}
			else {
				job_list.clear();
				job_list.resize(Newchrom[fac].size() + 1);
			}

			for (int jpos = 0; jpos < Seq.size(); jpos++) { 
				if (state == true) { 
					job_list[0] = Seq[jpos];
					Fcmax[jpos][fac] = GetFit_F(job_list, 1);
				}
				else {
					for (int i = 0; i < Newchrom[fac].size(); i++)
						job_list[i] = Newchrom[fac][i];
					job_list[Newchrom[fac].size()] = Seq[jpos];
					Fcmax[jpos][fac] = FindBestJobPos(job_list, job_list.size(), Newchrom[fac].size());
				}
			}//for (int jpos = 0; jpos < Seq.size(); jpos++) {
		} //for (int fac = 0; fac<gFactory; fac++)

		  
		int min_value = Fcmax[0][0], max_value = Fcmax[0][0];
		for (int jpos = 0; jpos < Seq.size(); jpos++) {
			for (int fac = 0; fac < gFactory; fac++) {
				if (Fcmax[jpos][fac] > max_value) {
					max_value = Fcmax[jpos][fac];
				}
				if (Fcmax[jpos][fac] < min_value) {
					min_value = Fcmax[jpos][fac];
				}
			}
		}
		double threshold = (double)min_value + alfa_parameter*((double)max_value - (double)min_value);
		int counter = 0;
		for (int jpos = 0; jpos < Seq.size(); jpos++) {
			for (int fac = 0; fac < gFactory; fac++) {
				if (Fcmax[jpos][fac] <= threshold) {
					counter++;
				}
			}
		}
		
		random_device rd;
		mt19937 gen1(rd());
		uniform_int_distribution<> distrib(1, counter);
		int randomValue = distrib(gen1);

		counter = 0;
		int job_decided = 0, dec_pos, dec_f;

		for (int jpos = 0; jpos < Seq.size(); jpos++) {
			for (int fac = 0; fac < gFactory; fac++) {
				if (Fcmax[jpos][fac] <= threshold) {
					counter++;
					if (counter == randomValue) {
						dec_pos = jpos;
						dec_f = fac;
						job_decided = 1;
						break;
					}
				}
			}
			if (job_decided == 1) {
				break;
			}
		}
		
		Newchrom[dec_f].resize(Newchrom[dec_f].size() + 1);
		Newchrom[dec_f][Newchrom[dec_f].size() - 1] = Seq[dec_pos];
		if (Newchrom[dec_f].size() > 1) {
			FindBestJobPos(Newchrom[dec_f], Newchrom[dec_f].size(), Newchrom[dec_f].size() - 1);
		}
		/**********************************/
		new_Seq.clear();
		new_Seq.resize(Seq.size() - 1);
		/*********************************/
		counter = 0;
		for (int jpos = 0; jpos < Seq.size(); jpos++) {
			if (jpos != dec_pos) {
				new_Seq[counter] = Seq[jpos];
				counter++;
			}
		}
		/**********************************/
		Seq = new_Seq;
		/*********************************/
	} //for (int jnumber = 0; jnumber < Seq.size(); jnumber++)

	minSpan = 0;
	for (int fac = 0; fac < gFactory; fac++) {
		if (Newchrom[fac].size() >=1) {
			int fact_makespan = GetFit_F(Newchrom[fac], Newchrom[fac].size()); //com.h
			if (fact_makespan > minSpan) {
				minSpan = fact_makespan;
			}
		}
	}
	/************************************************/
	return minSpan;
}



int In�t_Seq(vector<vector<unsigned short> >  &Chrom, double alfa_parameter)
{
	vector <unsigned short> Seq(gJobs);
	LPT(Seq); //com.h
	return Construction(Seq, Chrom, alfa_parameter);
}

int Destruction_Construction_it(vector<vector<unsigned short> >  &TempSeq, int pLen, double alfa_parameter) // pLen>0 && pLen<gJobs
{
	//Destruction: Randomly remove PLen jobs from OldSeq;
	int cnt = 0, maxSpan, newSpan, factor_index, i, fac, pos, l, a, TempSpan, L;
	unsigned short Tempch;
	vector <int> factory_pt(gFactory, -1);
	vector <int> factory_minSpan(gFactory, INT_MAX);
	
	maxSpan = 0;
	factor_index = -1;
	for (fac = 0; fac < gFactory; fac++) {
		if (TempSeq[fac].size() >= 1) {
			int fact_makespan = GetFit_F(TempSeq[fac], TempSeq[fac].size()); //com.h
			if (fact_makespan > maxSpan) {
				maxSpan = fact_makespan;
				factor_index = fac;
			}
		}
	}	

	int total_job_other_fac = 0;
	for (fac = 0; fac < gFactory; fac++) {	
		if (fac!= factor_index) {
			total_job_other_fac= total_job_other_fac+ TempSeq[fac].size();
		}
	}
	if (((pLen / 2) <= total_job_other_fac - (gFactory - 1)) && ((pLen / 2) <= TempSeq[factor_index].size() - 1)){
		vector <unsigned short> remove(pLen, 0);
		while (cnt < pLen / 2) {
			pos = rand() % TempSeq[factor_index].size();
			remove[cnt] = TempSeq[factor_index][pos];
			for (i = pos; i < TempSeq[factor_index].size() - 1; i++)
				TempSeq[factor_index][i] = TempSeq[factor_index][i + 1];
			TempSeq[factor_index].resize(TempSeq[factor_index].size() - 1);
			cnt++;
		}
		int sel_fac, j;
		for (j = cnt; j < pLen; j++) { 
			while (true) {
				sel_fac = rand() % gFactory;
				if (sel_fac != factor_index &&TempSeq[sel_fac].size() > 1) {
					break;
				}
			}
			pos = rand() % TempSeq[sel_fac].size();
			remove[j] = TempSeq[sel_fac][pos];
			for (i = pos; i < TempSeq[sel_fac].size() - 1; i++)
				TempSeq[sel_fac][i] = TempSeq[sel_fac][i + 1];
			TempSeq[sel_fac].resize(TempSeq[sel_fac].size() - 1);
		}
		maxSpan = Construction(remove, TempSeq, alfa_parameter);
	}//if ((pLen / 2) <= total_job_other_fac - (gFactory - 1)) {
	return maxSpan;
}


int LocalSearch(vector<vector<unsigned short> >  &TempSeq) // pLen>0 && pLen<gJobs
{
	int cnt = 0, pLen = 0, maxSpan, crt_fac, fac, pos, minSpan, sel_f;
	unsigned short Tempch;
	vector <int> factory_minSpan(gFactory, INT_MAX);

	for (fac = 0; fac < gFactory; fac++) {
		if (TempSeq[fac].size() > pLen) { 
			pLen = TempSeq[fac].size();
		}
	}
	
	while (cnt <= pLen) { 
		long ElapseTime = ::GetTickCount() - InitTime;
		if (ElapseTime >= TimeLimit)
		{
			break;
		}

		maxSpan = 0;
		crt_fac = -1;
		for (fac = 0; fac < gFactory; fac++) {
			if (TempSeq[fac].size() >= 1) {
				int fact_makespan = GetFit_F(TempSeq[fac], TempSeq[fac].size()); //com.h
				factory_minSpan[fac] = fact_makespan;
				if (fact_makespan > maxSpan) {
					maxSpan = fact_makespan;
					crt_fac = fac;
				}
			}
		}
		/************************************/
		for (fac = 0; fac < gFactory; fac++) {
			if (factory_minSpan[fac] == INT_MAX) {
				factory_minSpan[fac] = 2 * maxSpan;
			}
		}
		/********************************************/
		int total = 0;
		for (fac = 0; fac < gFactory; fac++) {
			total = total + factory_minSpan[fac];
		}
		//roulette wheel
		vector <double> exp_value(gFactory, 0);
		for (fac = 0; fac < gFactory; fac++) {
			exp_value[fac] = ((double)factory_minSpan[fac] / total);
		}
		vector <double> sum_exp_value(gFactory, 0);
		double totall;
		for (int i = 0; i < gFactory; i++) {
			totall = 0;
			for (int j = 0; j <= i; j++) {
				totall = totall + exp_value[j];
			}
			sum_exp_value[i] = totall;
		}
		while (1) {
			totall = (double)rand() / ((double)RAND_MAX + 1);
			for (int i = 0; i < gFactory; i++) {
				if (totall <= sum_exp_value[i]) {
					sel_f = i;
					break;
				}
			}
			if (TempSeq[sel_f].size() > 1) {
				break;
			}
		}
		//sel_f 
		pos = rand() % TempSeq[sel_f].size();
		Tempch = TempSeq[sel_f][pos];
		for (int i = pos; i < TempSeq[sel_f].size() - 1; i++)
			TempSeq[sel_f][i] = TempSeq[sel_f][i + 1];
		TempSeq[sel_f].resize(TempSeq[sel_f].size() - 1);
		int sel_fac_minSpan = GetFit_F(TempSeq[sel_f], TempSeq[sel_f].size());
		////////////////////////////////
		int system_minspan = 0, total_minspan = 0, decided_fac = -1;
		if (sel_f == crt_fac) {
			system_minspan = maxSpan;
		}
		else {
			total_minspan = factory_minSpan[sel_f];
		}	
		for (fac = 0; fac < gFactory; fac++) {
			if (sel_f == crt_fac) { 
				if (fac != sel_f) { 
					vector <unsigned short> job_insert(TempSeq[fac].size() + 1, -1);
					for (int i = 0; i < TempSeq[fac].size(); i++) {
						job_insert[i] = TempSeq[fac][i];
					}
					job_insert[job_insert.size() - 1] = Tempch;
					minSpan = FindBestJobPos(job_insert, job_insert.size(), job_insert.size() - 1);
					if (minSpan < system_minspan) {
						system_minspan = minSpan;
						decided_fac = fac;
					}
				}
			}
			else { 
				if (fac != crt_fac) { 
					if (fac != sel_f) { 
						total_minspan = total_minspan + factory_minSpan[fac];
						vector <unsigned short> job_insert(TempSeq[fac].size() + 1, -1);
						for (int i = 0; i < TempSeq[fac].size(); i++) {
							job_insert[i] = TempSeq[fac][i];
						}
						job_insert[job_insert.size() - 1] = Tempch;
						minSpan = FindBestJobPos(job_insert, job_insert.size(), job_insert.size() - 1);
						if (total_minspan > sel_fac_minSpan + minSpan) {
							total_minspan = total_minspan - factory_minSpan[fac];
							decided_fac = fac;
						}
					}
				}
			}
		}
		if (decided_fac != -1) {
			TempSeq[decided_fac].resize(TempSeq[decided_fac].size() + 1);
			TempSeq[decided_fac][TempSeq[decided_fac].size() - 1] = Tempch;
			minSpan = FindBestJobPos(TempSeq[decided_fac], TempSeq[decided_fac].size(), TempSeq[decided_fac].size() - 1);
			factory_minSpan[decided_fac] = minSpan;
			//cnt = 0;
			if (3 <= TempSeq[decided_fac].size()) {
				random_device rd;
				mt19937 gen(rd());
				uniform_int_distribution<> distrib(1, TempSeq[decided_fac].size());
				int TSpan;
				int factory_pos = distrib(gen);
				int h_index = factory_pos - 1;
				if (h_index != 0 && h_index < TempSeq[decided_fac].size() - 1) {
					TSpan = FindBestJobPos(TempSeq[decided_fac], TempSeq[decided_fac].size(), h_index - 1); //Operator.h
					TSpan = FindBestJobPos(TempSeq[decided_fac], TempSeq[decided_fac].size(), h_index + 1);
					factory_minSpan[decided_fac] = TSpan;
				}
				if (h_index == 0 || h_index == TempSeq[decided_fac].size() - 1) {
					minSpan = factory_minSpan[decided_fac];
					int Cont = 0, Poss = 0;
					do {
						TSpan = FindBestJobPos(TempSeq[decided_fac], TempSeq[decided_fac].size(), Poss);
						if (TSpan < minSpan)
						{
							minSpan = TSpan;
							Cont = 0;
						}
						else
							Cont++;
						Poss++;
						Poss = Poss%TempSeq[decided_fac].size();
					} while (Cont < TempSeq[decided_fac].size());
					factory_minSpan[decided_fac] = minSpan;
				}
			}
		}
		else {
			cnt++;
			TempSeq[sel_f].resize(TempSeq[sel_f].size() + 1);
			TempSeq[sel_f][TempSeq[sel_f].size() - 1] = Tempch;		
			minSpan = FindBestJobPos(TempSeq[sel_f], TempSeq[sel_f].size(), TempSeq[sel_f].size() - 1);
			factory_minSpan[sel_f] = minSpan;
			if (3 <= TempSeq[sel_f].size()) {
				random_device rd;
				mt19937 gen(rd());
				uniform_int_distribution<> distrib(1, TempSeq[sel_f].size());
				int TSpan;
				int factory_pos = distrib(gen);
				int h_index = factory_pos - 1;
				if (h_index != 0 && h_index < TempSeq[sel_f].size() - 1) {
					TSpan = FindBestJobPos(TempSeq[sel_f], TempSeq[sel_f].size(), h_index - 1); //Operator.h
					TSpan = FindBestJobPos(TempSeq[sel_f], TempSeq[sel_f].size(), h_index + 1);
					factory_minSpan[sel_f] = TSpan;
				}
				if (h_index == 0 || h_index == TempSeq[sel_f].size() - 1) {
					minSpan = factory_minSpan[sel_f];
					int Cont = 0, Poss = 0;
					do {
						TSpan = FindBestJobPos(TempSeq[sel_f], TempSeq[sel_f].size(), Poss);
						if (TSpan < minSpan)
						{
							minSpan = TSpan;
							Cont = 0;
						}
						else
							Cont++;
						Poss++;
						Poss = Poss%TempSeq[sel_f].size();
					} while (Cont < TempSeq[sel_f].size());
					factory_minSpan[sel_f] = minSpan;
				}
			}
		}

	} //wihile
	
	minSpan = 0;
	for (fac = 0; fac < gFactory; fac++) {
		if (TempSeq[fac].size() >= 1) {
			int fact_makespan = GetFit_F(TempSeq[fac], TempSeq[fac].size()); //com.h
			if (fact_makespan > minSpan) {
				minSpan = fact_makespan;
			}
		}
	}
	/************************************************/
	return minSpan;
}





