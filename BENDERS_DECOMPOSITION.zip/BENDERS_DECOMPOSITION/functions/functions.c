#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include "functions.h"

//CTime, Completion time; STime: Starting time
int GetFit_F(int *CTime, int m, unsigned short **pTime, unsigned short *chrom, int Len)//forward pass calculation
{

	int i, k, j, h, Cmax, jb;
	int max_value, total;

	//printf("Len = %d \n", Len);
	//printf("chromosome:\n");
	//for (k = 0; k < Len; k++) {
	//printf("%d ", chrom[k]);
	//}
	//printf("\n");
	for (jb = 0; jb < Len - 1; jb++)
	{
		CTime[jb] = 0;
		i = chrom[jb];
		j = chrom[jb + 1];
		//printf("i= %d ", i);
		//printf("j= %d ", j);
		max_value = 0;
		for (k = 1; k <= m; k++) {
			total = 0;
			for (h = k; h <= m; h++) {
				total = total + (pTime[j][h] - pTime[i][h]);
			}
			total = total + pTime[i][k];
			//printf("total = %d \n", total);
			if (total > max_value) {
				max_value = total;
				//printf("max_value = %d \n", max_value);
			}
		}
		CTime[jb] = max_value;
		//printf("%d \n", CTime[jb]);
	}
	total = 0;
	for (k = 0; k < Len - 1; k++) {
		total = total + CTime[k];
	}
	//printf("total = %d \n", total);
	for (i = 1; i <= m; i++) {
		total = total + pTime[chrom[0]][i];
	}
	//printf("total = %d \n", total);
	Cmax = total;
	//printf("cmax = %d \n", Cmax);
	return Cmax;
}

