int GetFit_F(int **STime, int **CTime, int **STimeb, int **CTimeb, int *TCTime, int *TSTime, int *TSTimeb, int *TCTimeb, int m, unsigned short **pTime, unsigned short *chrom, int Len);
int GetFit_B(int **STime, int **CTime, int **STimeb, int **CTimeb, int *TCTime, int *TSTime, int *TSTimeb, int *TCTimeb, int m, unsigned short **pTime, unsigned short *chrom, int Len);
